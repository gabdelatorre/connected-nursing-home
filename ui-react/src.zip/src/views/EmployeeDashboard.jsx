import React, { Component } from "react";
import { FirebaseContext } from "../firebase";
import { withFirebase } from "../firebase/context";
import PatientCard from "./PatientCard";

class EmployeeDashboard extends Component {
  constructor() {
    super();
    this.state = {
      arrOfPatients: [],
      rows: 0
    };
  }
  componentDidMount() {
    this.props.firebase
      .users()
      .get()
      .then(e => {
        e.docs.forEach(data => {
          this.setState({
            arrOfPatients: this.state.arrOfPatients.concat(data.data())
          });
        });
      });
  }

  render() {
    const patientInfo = this.state.arrOfPatients.map(pat => {
      return (
        <div className="items">
          <PatientCard
            firstName={pat.firstName}
            lastName={pat.lastName}
            birthdate="SampleText"
            nurseAssigned="SampleText"
          />
        </div>
      );
    });
    return (
      <div>
        <section id="allPatients">
          <div className="containerSection">
            <div className="items">
              <h3>All Patients</h3>
            </div>
            <div className="items">
            <input type="text" id="txt" onKeyDown={this.search.bind(this)} />
            </div>
          </div>
        </section>
        <hr className="style-one" />
        <div className="container">{patientInfo}</div>
      </div>
    );
  }
}

export default withFirebase(EmployeeDashboard);
