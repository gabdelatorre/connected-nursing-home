import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

class Home extends Component {

    constructor(props) {
        super(props);
        this.state = {
        }
    }

    componentDidMount () {
    }

    /* ===================================================================== */
    /* ========================== FUNCTIONALITIES ========================== */
    /* ===================================================================== */

    /* ===================================================================== */
    /* ============================== RENDER =============================== */
    /* ===================================================================== */

    render() {

        return (
            <div>
            </div>
        )
    }
}

export default withRouter(Home);
