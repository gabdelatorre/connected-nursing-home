var userDB = [
    // USER - CHARITY ORGS //
];

module.exports = {
    userDB,
}