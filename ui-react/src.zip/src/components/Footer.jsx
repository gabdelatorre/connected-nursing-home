import React, { Component } from 'react';

class Footer extends Component {

    render() {
        return (
            <div>
                I'm a footer..
            </div>
        );
    }
}

export default Footer;
